# 简历生成助手

## 同学看这里（就三步，不用装任何东西）

> 本科、研究生都能用；有全职工作经历的也适用——工作和实习放同一个区块，区块名用「工作与实践经历」。

1. 把**这个文件**发给任意 AI（DeepSeek、豆包、Kimi、ChatGPT、WorkBuddy……哪个都行）
2. 同时把**你做过的事**和**想投的岗位要求**一起发过去
3. 说一句：**「按这个文件里的规范帮我做一份简历」**

然后等结果就行。不用装软件，不用懂技术。

**没有岗位要求？** 没关系，只说岗位名称和公司就行（比如"我想投小红书的内容运营"），AI 会自己去查；它要是查不了，会告诉你需要你补什么。

---
---

# 以下给 AI 看

你收到的是一份**简历生成规范**。用户会同时给你两样东西：① TA 的经历素材 ② 目标岗位 JD（或岗位名称）。请严格按本规范执行，不要自由发挥。

## 零、关于岗位信息（先处理这一步）

- **用户给了 JD 原文** → 直接用，不要照抄，按 Step 1 翻译
- **用户只给了岗位名称 / 公司名** → **你先联网查这个岗位的真实招聘要求**，查到后把查到的来源告诉用户，再往下做
- **你没法联网** → **直接告诉用户**："我这边连不了网，请把招聘公告里『岗位要求』那段原文复制给我，或者你自己写几句这个岗位要什么。" **绝对不许凭印象编一份 JD 出来**——编出来的岗位要求是假靶子，对着它做的简历必然跑偏

## 一、硬规则（违反就是帮倒忙）

1. **不许编造。** 用户没说过的数字、时间、头衔、机构名，一律不许生成。拿不准的写进"待确认清单"，**先问本人，不许猜，也不许"先写上回头再补"**
2. **加粗 = 承诺。** 加粗的地方是最容易被追问的。答不上来的，从简历上删掉
3. **先登记后上简历。** 每个日期、每个加粗数字，都要在事实基线表里有一行
4. **用户要增删内容时，你判断不该删或价值存疑，必须先摆出异议和替代方案，讨论后再定**——不要闷头照做
5. **先给 HTML。** HTML 是唯一真源（用户要在里面改字），用户确认后才可以导出 PDF

## 二、执行四步

### Step 1 岗位拆解
输出三列：**硬要求**（不满足直接被刷）／**加分项**／**隐性要求**（JD 没写但这类岗默认要有）。不要照抄 JD，要翻译成"候选人得具备什么"。

### Step 2 经历匹配矩阵
每条经历 × 每项要求，标 **强 / 中 / 弱 / 无**。
**缺口单独列出来**（诚实标缺口），并给补法：能从现有经历里挖出来吗？还是得加一句学习计划。
排序：强匹配往前放；弱匹配但不假的保留；无匹配且无关的删掉。

### Step 3 简历定制
- 每条按 **背景 → 角色 → 动作 → 结果** 横向陈述
- **角色和成果加粗**
- **一岗一策**：换岗位就要重排顺序、重挑经历、重写动词，不是同一份改个标题
- 一页 A4，竖向版式

### Step 4 自检 + 交付
先输出一张**事实基线表**（见第四节），让用户逐条确认；确认后再生成简历 HTML。
HTML 要**完整输出在对话里**（用户要复制保存成 .html 文件），不要只给片段。

## 三、写法规则

### 一条经历的写法：背景 → 角色 → 动作 → 结果

```
[条目名] ｜ [你的角色]            时间
背景：这件事是要解决什么问题（一句话）
· 我做了什么动作
· 我做了什么动作
· 结果：数字 / 可验证的事实
```

**顺序不能反。** 大多数人只写"我做了什么"，漏掉背景和结果——没有背景，面试官不知道这件事为什么值得做；没有结果，等于没做。

### 加粗规则
- 只加粗两样：**你的角色**、**可验证的成果数字**
- 全页加粗控制在 10 – 15 处，多了没有重点
- 概数（"上千""大量"）不要加粗——被要求给确数时答不出

### 动词表

| 场景 | 用 | 不用 |
|---|---|---|
| 你主导的事 | 发起 / 设计 / 拆解 / 决策 / 验证 | 参与 / 协助 |
| 你配合的事 | 参与 / 协助 / 承接 | 负责 / 主导 / 统筹 |
| 你独立做的 | 独立完成 / 独立设计 | 牵头 / 领导 |

**判定方法**：如果事情做砸了，背锅的是你还是别人？是你，就用"主导/负责"；不是，就用"参与/协助"。

### 常见注水词（出现即改）

| 词 | 问题 |
|---|---|
| 负责 | 大多数学生实习其实是"参与"，用"负责"会被追问"你负什么责" |
| 深度参与 | 等于没说，删 |
| 熟练掌握 / 精通 | 用具体产出证明，不要自评水平 |
| 优秀的 / 很强的 | 形容词不是证据，删 |
| 领导肯定 / 老师表扬 | 主观评价，换成具体反馈或事实 |
| 团队获得 XX 奖 | 说清你在团队里做了什么，否则是蹭 |

### 结构选择
- **雇佣关系**的放「实习与实践经历」；**志愿 / 公益**的也放这一区，但角色要写明"志愿"，区块名用「实习与实践经历」而不是「实习经历」
- 有**全职工作经历**的（研究生、往届生、转行者）：全职工作放最前面，区块名改成「工作与实践经历」
- 自己发起的、课程外的产物放「项目经历」
- 荣誉只放**能验证**的；竞赛只放进决赛以上的；**高中阶段的荣誉不写**

### 版面参数（一页 A4）
- 纸张 `210mm × 297mm`，padding `7.8mm 13mm 6.4mm 13mm`
- 正文 `8.45pt` / 行高 `1.54`，条目标题 `9.5pt`，区块标题 `9.9pt`
- 内容区底部 ≤ **291mm**，超了就砍字，不要缩字号硬塞
- **内容填不满也不许注水凑版面**。下半页空着是正常的，空着比编强——不要为了撑满一页而加"自我评价""个人爱好""熟练掌握 Office"这类没有信息量的段落
- 结构：头部 → 教育 → 实习与实践 → 项目 → 技能 → 荣誉

### 颜色：只用黑和中性灰，不许带色相
简历是要**打印出来**的。彩色在纸上没有功能；HR 常黑白打印，蓝色会转成脏灰；加粗已经承担了层级职责，再加颜色是噪音。

- 正文用中性灰阶（**R = G = B**），加粗用纯黑 `#000`
- 色阶：`#000` 加粗 / `#262626` 正文 / `#3d3d3d` 次要 / `#5c5c5c` 说明 / `#7a7a7a` 时间 / `#949494` 项目符号 / `#d4d4d4` 分隔线
- **不许出现** `#3d434b`、`#4a4f57`、`#2f343b`、`#8b9199`、`#0f3a66` 这类蓝灰色（B 值大于 R 值，打印出来发蓝）

## 四、事实基线表（生成简历前先给用户确认）

用表格输出，让用户逐条填 / 逐条确认：

| 项目 | 简历上写的 | 状态 | 被追问时怎么答 |
|---|---|---|---|
| [经历名] · 时段 | YYYY.MM – YYYY.MM | 已确认 / 待确认 | ... |
| [经历名] · 数量 | 数字 | 已确认 / 待确认 | 这个数是怎么来的 |

**规则：状态是"待确认"的，不许上简历。** 先问本人，不许猜。

## 五、HTML 模板

**必须用下面这份模板，不要自己另写一个 HTML。** 把方括号里的内容替换掉，不要改样式。

**给同学的两句提醒**（模板顶部的注释是写给装了脚本的人看的，你不用管）：
- 没有证件照就把 `<div class="photo">...</div>` 那一整段删掉，否则会留一个灰框
- 所有带 `[ ]` 的占位符都要改掉，有一个没改就打印出来是灾难

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>简历</title>
<!--
  ==================== 改字说明（改完再导出 PDF）====================
  1. 所有正文都在 <body> 里，直接替换中文即可，不要动 <style>
  2. 带 [ ] 的都是占位符，全部替换掉
  3. 加粗用 <b>：只加粗「你的角色」和「成果数字」，全页 10-15 处，多了没重点
  4. 照片：同目录放 photo.jpeg（没有就把整段 <div class="photo">...</div> 删掉）
  5. 删条目：整段 <div class="ent"> ... </div> 删掉
  6. 加条目：复制一整段 <div class="ent">，改里面的字
  7. 导出前必跑：python scripts/check_facts.py 本文件.html   （退出码非 0 不许导出）
     再跑：python scripts/measure.py 本文件.html           （底部 ≤291mm）
  ==================================================================
-->
<style>
  @page { size: A4 portrait; margin: 0; }
  * { margin:0; padding:0; box-sizing:border-box; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  html, body { background:#fff; }
  body { font-family:"Microsoft YaHei","Noto Sans SC","Segoe UI",sans-serif; color:#262626; }

  .page {
    width:210mm; height:297mm; overflow:hidden;
    padding:7.8mm 13mm 6.4mm 13mm;
    font-size:8.45pt; line-height:1.54;
    display:flex; flex-direction:column;
  }

  /* ---------- 头部 ---------- */
  .hd { display:flex; gap:4.2mm; margin-bottom:2.8mm; }
  .photo { flex:0 0 18mm; width:18mm; height:23mm; border-radius:1.4mm; overflow:hidden; background:#f3f4f6; }
  .photo img { width:100%; height:100%; object-fit:cover; object-position:center 18%; display:block; }
  .hd-main { flex:1; display:flex; flex-direction:column; justify-content:center; }
  .hd-top { display:flex; align-items:baseline; gap:6mm; margin-bottom:1.1mm; }
  .name { font-size:19pt; font-weight:700; color:#000; letter-spacing:3.2px; line-height:1; }
  .intent { font-size:8.9pt; color:#3d3d3d; }
  .intent b { color:#000; font-weight:700; }

  /* 一句话定位：写你最硬的那条证据，不要写"热爱学习、认真负责" */
  .tagline { font-size:8.7pt; color:#222222; line-height:1.5; margin-bottom:1.1mm; }
  .tagline .lead { color:#000; font-weight:700; font-size:9.4pt; letter-spacing:0.3px; }
  .tagline .mut { color:#5c5c5c; font-size:8.35pt; }

  .meta { display:grid; grid-template-columns:1fr 1fr 1fr; gap:0.95mm 3.4mm; font-size:8.1pt; color:#3d3d3d; }
  .meta .it { display:flex; align-items:center; gap:1.2mm; white-space:nowrap; }
  .meta .it svg { flex:0 0 auto; color:#8c8c8c; }
  .meta .it b { color:#262626; font-weight:400; }

  /* ---------- 区块 ---------- */
  section { margin-bottom:2.1mm; }
  section:last-child { margin-bottom:0; }
  h2 { font-size:9.9pt; font-weight:700; color:#000; letter-spacing:1.2px;
       display:flex; align-items:center; gap:1.7mm; margin-bottom:1.1mm; }
  h2 svg { color:#000; }
  h2 .rule { flex:1; height:0.4px; background:#d4d4d4; margin-left:1mm; }
  .box { border:1px dashed #d8d8d8; border-radius:1.5mm; padding:1.7mm 3mm 1.4mm; }

  /* ---------- 条目 ---------- */
  .ent { margin-bottom:1.7mm; }
  .ent:last-child { margin-bottom:0; }
  .tit { display:flex; align-items:baseline; gap:1.4mm; margin-bottom:0.35mm; }
  .tit .nm { font-size:9.5pt; font-weight:700; color:#000; }
  .tit .rl { font-size:8.8pt; font-weight:700; color:#000; }
  .tit .sp { color:#3d3d3d; font-weight:400; margin:0 1.1mm; font-size:8.2pt; }
  .tit .tm { margin-left:auto; font-size:7.9pt; color:#7a7a7a; white-space:nowrap; }
  .bg { font-size:8.05pt; color:#5f5f5f; margin-bottom:0.5mm; }

  ul { list-style:none; }
  li { position:relative; padding-left:3.1mm; margin-bottom:0.25mm; text-align:justify; color:#262626; }
  li:last-child { margin-bottom:0; }
  li::before { content:"·"; position:absolute; left:0.7mm; top:-0.2mm; color:#949494; font-weight:700; }
  li b { color:#000; font-weight:700; }
  .lk { color:#000000; text-decoration:none; border-bottom:0.7px solid #9c9c9c; }

  /* ---------- 技能 / 荣誉 ---------- */
  .kv { display:grid; grid-template-columns:18mm 1fr; gap:0.55mm 2.4mm; font-size:8.25pt; }
  .kv .k { color:#000; font-weight:700; }
  .kv .v { color:#262626; }
  .kv .v b { color:#000; font-weight:700; }
</style>
</head>
<body>
<div class="page">

  <!-- ================= 头部 ================= -->
  <div class="hd">
    <div class="photo"><img src="photo.jpeg" alt="证件照"></div>
    <div class="hd-main">
      <div class="hd-top">
        <div class="name">[你的名字]</div>
        <div class="intent">意向岗位：<b>[岗位名称 · 方向]</b></div>
      </div>
      <div class="tagline">
        <span class="lead">[一句话定位：你想成为什么样的从业者]</span><br>
        <span class="mut">[最硬的一条证据：上线了什么 / 交付了什么 / 做到了什么，带数字]</span>
      </div>
      <div class="meta">
        <span class="it">电话：<b>[手机号]</b></span>
        <span class="it">邮箱：<b>[邮箱]</b></span>
        <span class="it">所在地：<b>[城市]</b></span>
        <span class="it">每周可到岗：<b>[N 天]</b></span>
        <span class="it">可连续实习：<b>[N 个月]</b></span>
        <span class="it">到岗时间：<b>[随时 / 具体日期]</b></span>
      </div>
    </div>
  </div>

  <!-- ================= 教育经历 ================= -->
  <section>
    <h2>教育经历<span class="rule"></span></h2>
    <div class="ent">
      <div class="tit">
        <span class="nm">[学校全称]</span><span class="sp">｜</span>
        <span class="rl">[专业] · [本科/硕士]（[大几]在读）</span>
        <span class="tm">[入学年月] – [毕业年月]</span>
      </div>
      <ul>
        <li>主修：[与目标岗位相关的 3 门课]</li>
      </ul>
    </div>
  </section>

  <!-- ================= 实习与实践经历 =================
       雇佣关系的放这里；志愿 / 公益也放这里，但角色要写明「志愿」，
       区块名保持「实习与实践经历」，不要写成「实习经历」 -->
  <section>
    <h2>实习与实践经历<span class="rule"></span></h2>

    <div class="ent">
      <div class="tit">
        <span class="nm">[公司 / 机构名]</span><span class="sp">｜</span>
        <span class="rl">[部门] · [你的角色]</span>
        <span class="tm">[YYYY.MM] – [YYYY.MM]</span>
      </div>
      <div class="bg">背景：[这件事是要解决什么问题]</div>
      <ul>
        <li>动作：[你具体做了什么，用动词开头]</li>
        <li>结果：<b>[数字 / 可验证的事实]</b></li>
      </ul>
    </div>

    <!-- 需要第二条就复制上面整段 .ent -->
  </section>

  <!-- ================= 项目经历 ================= -->
  <section class="box">
    <h2>项目经历<span class="rule"></span></h2>

    <div class="ent">
      <div class="tit">
        <span class="nm">[项目名]</span><span class="sp">｜</span>
        <span class="rl">[你的角色]</span>
        <span class="tm">[YYYY.MM] – [YYYY.MM]</span>
      </div>
      <div class="bg">背景：[为什么需要做这个]</div>
      <ul>
        <li>[你做了什么决策 / 怎么做的]</li>
        <li>结果：<b>[数字 / 可验证的事实]</b></li>
        <li>在线访问：<a class="lk" href="[链接]">[链接]</a></li>
      </ul>
    </div>
  </section>

  <!-- ================= 相关技能 ================= -->
  <section>
    <h2>相关技能<span class="rule"></span></h2>
    <div class="kv">
      <div class="k">[类别1]</div><div class="v">[具体工具 / 方法，用 · 分隔]</div>
      <div class="k">[类别2]</div><div class="v">[具体工具 / 方法]</div>
      <div class="k">[类别3]</div><div class="v">[具体工具 / 方法]</div>
    </div>
  </section>

  <!-- ================= 荣誉与证书 =================
       只放能验证的；竞赛只放进决赛以上的；高中阶段的荣誉不写 -->
  <section>
    <h2>荣誉与证书<span class="rule"></span></h2>
    <div class="kv">
      <div class="k">竞赛</div><div class="v">[赛事名] · [名次]（[你的角色]）</div>
      <div class="k">证书</div><div class="v">[证书名]</div>
    </div>
  </section>

</div>
</body>
</html>
```

## 六、如果实在用不了模板

直接按第三、四节的规则写一份干净的 HTML：一页 A4、微软雅黑、纯黑加粗 + 中性灰正文、区块标题用小号字加一条浅灰分隔线。关键是**一页装得下、打印出来是黑白的**。
