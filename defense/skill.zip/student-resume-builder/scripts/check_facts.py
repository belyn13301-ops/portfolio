# -*- coding: utf-8 -*-
"""
简历敏感信息自检 —— 五道闸（时段 / 数字 / 禁用词 / 占位符 / 色系）
用法（在工作目录里）：  python check_facts.py 简历.html [facts.json]
退出码 0 = 通过可以导出 PDF；1 = 有问题，不许导出。

闸一 学期对撞：把条目的时间换算成学期（寒假/暑假/大几），和标题里的"寒假/暑期"对撞
闸二 基线比对：出现的日期必须是 facts.json 里同一条经历登记过的；列出全部加粗数字供逐条核对
闸三 禁用词：按 scope 精确匹配到条目，不误伤其他条目
"""
import re, sys, json, os

# Windows 控制台默认 GBK，中文报告可能炸；强制 UTF-8 输出
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

SRC = sys.argv[1] if len(sys.argv) > 1 else 'resume.html'
FJ  = sys.argv[2] if len(sys.argv) > 2 else 'facts.json'

if not os.path.exists(SRC):
    sys.exit('找不到简历文件：%s' % SRC)
facts = json.load(open(FJ, encoding='utf-8')) if os.path.exists(FJ) else \
    sys.exit('找不到事实基线 %s —— 先复制 assets/facts_template.json 并填写' % FJ)

# 入学时间：用于把月份换算成学期
enroll = facts.get('enroll', '')
m = re.match(r'(\d{4})\.(\d{2})', enroll or '')
ENROLL_Y = int(m.group(1)) if m else None
# level：本科（默认）/ 硕士。写在 facts.json 里，例如 "level": "硕士"
LEVEL = str(facts.get('level', '本科') or '本科')
IS_GRAD = ('硕' in LEVEL) or ('研' in LEVEL)
GN = {1: '研一', 2: '研二', 3: '研三', 4: '研四', 5: '研五'} if IS_GRAD else \
     {1: '大一', 2: '大二', 3: '大三', 4: '大四', 5: '大五'}
YEARS = 3 if IS_GRAD else 4          # 学制：硕士 3 年 / 本科 4 年

def strip_noise(h):
    h = re.sub(r'<!--.*?-->', ' ', h, flags=re.S)
    h = re.sub(r'<style.*?</style>', ' ', h, flags=re.S)
    h = re.sub(r'<script.*?</script>', ' ', h, flags=re.S)
    return h

def text_of(f):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', f)).strip()

def term_of(y, mo):
    gy = (y - ENROLL_Y + 1) if mo >= 9 else (y - ENROLL_Y)
    # 早于入学（本科阶段 / 工作经历）或已毕业：学制不适用，不要算出「第-6年」这种荒谬标签
    if gy < 1:
        return '入学前', ''
    if gy > YEARS:
        return '毕业后', ''
    gn = GN.get(gy, '第%d年' % gy)
    if mo in (1, 2):  return gn, '寒假'
    if mo in (7, 8):  return gn, '暑假'
    if 3 <= mo <= 6:  return gn, '春季学期(下)'
    return gn, '秋季学期(上)'

def span_label(a, b):
    ga, ta = term_of(*a); gb, tb = term_of(*b)
    return ('%s%s' % (ga, ta)) if (ga == gb and ta == tb) else ('%s%s → %s%s' % (ga, ta, gb, tb))

def extract_ents(h):
    """用 div 栈精确切出每个 <div class="ent">，正则在嵌套结构下会失配"""
    out, i = [], 0
    while True:
        mm = re.search(r'<div class="ent">', h[i:])
        if not mm: break
        j = i + mm.end(); depth = 1
        while depth > 0:
            o = h.find('<div', j); c = h.find('</div>', j)
            if c == -1: break
            if o != -1 and o < c: depth += 1; j = o + 4
            else:                 depth -= 1; j = c + 6
        out.append(h[i + mm.end(): j - 6]); i = j
    return out

body = strip_noise(open(SRC, encoding='utf-8').read())
ents = extract_ents(body)
problems, warns, rows = [], [], []

def anchor_hit(anchor, full_text):
    """锚是否命中：支持 | 分隔多个候选词，比较时忽略空格。
    只看连续子串太脆（「二手平台」配不上「校园二手交易平台」），
    所以允许填多个候选，任一命中即可。"""
    t = full_text.replace(' ', '')
    for k in str(anchor).split('|'):
        k = k.strip().replace(' ', '')
        if k and k in t:
            return True
    return False

# ---- 闸一 ----
anchor_hits = set()
for e in ents:
    mtit = re.search(r'<div class="tit">(.*?)</div>', e, re.S)
    mtm  = re.search(r'<span class="tm">(.*?)</span>', e, re.S)
    if not mtm: continue
    tm  = text_of(mtm.group(1))
    tit = text_of(mtit.group(1)) if mtit else text_of(e)[:30]
    tit = (tit.replace(tm, '').strip() or tit)   # 标题里去掉时间，报告才不重复显示
    ds  = sorted({(int(a), int(b)) for a, b in re.findall(r'(\d{4})\.(\d{2})', tm)})
    if not ds: continue
    label = span_label(ds[0], ds[-1]) if ENROLL_Y else '（未填 enroll，跳过学期换算）'
    rows.append('%-32s %-16s → %s' % (tit[:32], tm, label))
    if not ENROLL_Y: continue
    # 学期 - 措辞对撞（入学前 / 毕业后的经历不适用学制，不做对撞）
    if '入学前' not in label and '毕业后' not in label:
        for w, expect in [('寒假', '寒假'), ('暑期', '暑假'), ('暑假', '暑假')]:
            if w in tit and expect not in label.split('→')[-1].strip():
                problems.append('【学期冲突】「%s」标题写「%s」，但时间 %s 推算出是「%s」' % (tit[:26], w, tm, label))
    # 日期与基线严格比对（按锚点锁定到这一条经历）
    allowed = set()
    for c in facts.get('confirmed', []):
        a = (c.get('锚') or '').strip()
        if not a:
            continue
        if anchor_hit(a, text_of(e)):
            allowed |= set(re.findall(r'\d{4}\.\d{2}', str(c['值'])))
            anchor_hits.add(a)
    if allowed:
        bad = ['%d.%02d' % d for d in ds if '%d.%02d' % d not in allowed]
        if bad:
            problems.append('【日期与基线不符】「%s」出现 %s，但基线里这条只登记了 %s'
                            % (tit[:22], '、'.join(bad), '、'.join(sorted(allowed))))
    else:
        warns.append('【这条没登记】「%s」时间 %s —— 基线里没有任何锚点能对上它，'
                     '等于这条日期没被校验。补一条 confirmed，锚填条目里连续出现的字' % (tit[:22], tm))

# 锚点整体没配上 = 基线形同虚设，必须提醒（否则检查在跑、其实什么都没查）
for c in facts.get('confirmed', []):
    a = (c.get('锚') or '').strip()
    if a and a not in anchor_hits:
        warns.append('【锚点没配上】基线里的锚「%s」在任何条目里都没出现 —— 这条基线没生效。'
                     '锚要填条目里连续出现的字，拿不准就写两个候选：如「二手|交易」' % a)

# ---- 闸二：加粗数字清单 ----
num_bolds = [text_of(b) for b in re.findall(r'<b>(.*?)</b>', body, re.S) if re.search(r'\d', b)]

# ---- 闸三：禁用词 ----
for b in facts.get('banned', []):
    scope = b.get('scope', 'ALL')
    if scope == 'ALL':
        if b['词'] in text_of(body):
            problems.append('【禁用词·全文】「%s」—— %s' % (b['词'], b['原因']))
    else:
        for e in ents:
            t = text_of(e)
            if any(s in t for s in scope.split('|')) and b['词'] in t:
                problems.append('【禁用词】「%s」出现在「%s…」—— %s' % (b['词'], t[:20], b['原因']))

# ---- pending 提醒 ----
for p in facts.get('pending', []):
    for e in ents:
        if p['项'][:4] in text_of(e):
            warns.append('【待本人确认】%s → %s' % (p['项'], p['待确认'])); break

# ---- 闸五 占位符残留：模板改到一半就导出，是最常见的翻车 ----
_txt = text_of(body)
_leftover = re.findall(r'[\[【][^\]】]{1,40}[\]】]', _txt)
_leftover += re.findall(r'YYYY\.MM', _txt)
if _leftover:
    problems.append('【占位符没改完】简历里还剩：%s —— 全部换成真实内容再导出，'
                    '打印出来带着方括号就完了'
                    % '、'.join(list(dict.fromkeys(_leftover))[:8]))

# ---- 闸四 色系统一：打印稿必须纯黑灰，不许带色相 ----
_raw = open(SRC, encoding='utf-8').read()
_css = re.search(r'<style[^>]*>(.*?)</style>', _raw, re.S)
_scope = _css.group(1) if _css else _raw
_hues = []
for _h in sorted(set(re.findall(r'#([0-9a-fA-F]{6})\b', _scope))):
    r_, g_, b_ = int(_h[0:2], 16), int(_h[2:4], 16), int(_h[4:6], 16)
    if max(r_, g_, b_) - min(r_, g_, b_) > 12:      # R/G/B 差值大 = 有色相
        _hues.append('#' + _h)
if _hues:
    problems.append('【色偏】简历要打印，色系必须纯黑灰（R=G=B）。发现带色相的颜色：%s'
                    ' —— 改成中性灰阶（例：#3d434b → #262626）' % '、'.join(_hues))

print('=== 简历自检报告：%s ===' % SRC)
print('\n--- 闸一 时段推算（一眼看寒暑假对不对）---')
if rows:
    print('\n'.join(rows))
elif ents:
    print('(识别到 %d 个条目，但时间还是占位符 [YYYY.MM] —— 替换成真实日期后才会做学期对撞)' % len(ents))
else:
    print('(没识别到条目，检查 class="ent" / class="tm" 是否被改过)')
print('\n--- 闸二 加粗成果数字（%d 处，逐条能对上事实才能发）---\n%s'
      % (len(num_bolds), ' ｜ '.join(num_bolds) or '（无）'))
if warns:
    print('\n--- 待本人确认（问本人，不要猜）---\n' + '\n'.join(dict.fromkeys(warns)))
print('\n--- 闸五 占位符（漏改就打印 = 灾难）---\n%s' % ('没有残留' if not _leftover else '、'.join(dict.fromkeys(_leftover))))
print('\n--- 闸四 色系（打印稿必须纯黑灰）---\n%s' % ('全部为中性灰阶，无色偏' if not _hues else '、'.join(_hues) + ' ← 有色偏'))
print()
if problems:
    print('!!! 不通过，%d 个问题：\n' % len(problems) + '\n'.join(problems))
else:
    print('五道闸全部通过，可以导出 PDF。')
sys.exit(1 if problems else 0)
