# -*- coding: utf-8 -*-
"""
简历高度测量：确认内容没有超出一页 A4。
用法： python measure.py 简历.html
判定：最后一个区块的底部 ≤ 291mm 才安全（页面可用高度 297 - 上边距 7.8 ≈ 289，取 291 为上限）。
"""
import subprocess, re, sys, os
from pathlib import Path
from urllib.parse import quote

# Windows 控制台默认 GBK，中文报告可能炸；强制 UTF-8 输出
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

SRC = sys.argv[1] if len(sys.argv) > 1 else 'resume.html'
if not os.path.exists(SRC):
    sys.exit('找不到文件：%s' % SRC)

CANDIDATES = [
    r'C:/Program Files/Google/Chrome/Application/chrome.exe',
    r'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
    os.path.expanduser(r'~/AppData/Local/Google/Chrome/Application/chrome.exe'),
    r'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    r'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
    # Mac
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    os.path.expanduser('~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    # Linux
    '/usr/bin/google-chrome', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge',
]
chrome = next((c for c in CANDIDATES if os.path.exists(c)), None)
if not chrome:
    sys.exit('没找到 Chrome 或 Edge，无法测量。'
             '\n装一个浏览器即可，或者跳过这一步——直接在浏览器里打开 HTML'
             '（Ctrl+P 打印预览，看是不是正好一页）。')

h = open(SRC, encoding='utf-8').read()
js = '''<script>
window.addEventListener("load",function(){
  var mm=96/25.4, out=[];
  var p=document.querySelector(".page"); if(!p){document.body.appendChild(document.createTextNode("MEASURE|NO_PAGE"));return;}
  var pr=p.getBoundingClientRect();
  document.querySelectorAll("section").forEach(function(s,i){
    out.push("S"+(i+1)+"_bottom="+((s.getBoundingClientRect().bottom-pr.top)/mm).toFixed(1));
  });
  document.querySelectorAll("li").forEach(function(li,i){
    var lh=parseFloat(getComputedStyle(li).lineHeight);
    out.push("li"+(i+1)+"_lines="+Math.round(li.getBoundingClientRect().height/lh));
  });
  var d=document.createElement("div"); d.textContent="MEASURE|"+out.join("|");
  document.body.appendChild(d);
});
</script>'''
tmp = '_measure_tmp.html'
open(tmp, 'w', encoding='utf-8').write(h.replace('</body>', js + '\n</body>'))

url = 'file:///' + quote(str(Path(tmp).resolve()).replace('\\', '/'))
out = subprocess.run([chrome, '--headless', '--disable-gpu', '--virtual-time-budget=3000',
                      '--window-size=794,1123', '--dump-dom', url],
                     capture_output=True, text=True, encoding='utf-8', errors='ignore').stdout
os.remove(tmp)

m = re.findall(r'MEASURE\|[^<]*', out)
if not m:
    sys.exit('测量失败，检查 HTML 是否有 .page 容器')
parts = m[-1].replace('MEASURE|', '').split('|')
bottoms = [float(p.split('=')[1]) for p in parts if p.startswith('S') and '_bottom' in p]
if not bottoms:
    sys.exit('没测到区块，检查 <section> 结构')
last = max(bottoms)
print('各区块底部（mm）：', ' '.join('%.1f' % b for b in bottoms))
print('内容底部：%.1f mm  （上限 291）' % last)
if last > 291:
    print('!!! 超出一页：需要砍 %.1f mm 的内容（删条目或缩句子，不要靠缩字号硬塞）' % (last - 291))
    sys.exit(1)
print('高度 OK，剩余空间 %.1f mm' % (291 - last))
if last < 240:
    print('\n提示：内容只占一页的 %.0f%%，下半页是空的。' % (last / 291 * 100))
    print('      简历太空比太满更吃亏——建议补条目（课程项目、比赛、社团都算），'
          '或把正文字号从 8.45pt 调到 9pt、行高 1.54 调到 1.6。')
    print('      （如果这就是你全部的经历，那就保持——空着也比编强。）')
